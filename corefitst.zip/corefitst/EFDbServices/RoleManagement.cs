﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EFDbServices
{
    /// <summary>
    /// 角色管理
    /// </summary>
    public class RoleManagement : ModelBaseClassLib
    {
        /// <summary>
        /// 角色编码
        /// </summary>
        //[Unique]
        public string RoleCode { get; set; }
        /// <summary>
        /// 角色名称
        /// </summary>
        //[Unique]
        public string RoleName { get; set; }
    }
}
