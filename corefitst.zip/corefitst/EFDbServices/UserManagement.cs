﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EFDbServices
{
    /// <summary>
    /// 用户管理
    /// </summary>
    public class UserManagement : ModelBaseClassLib
    {

        /// <summary>
        /// 姓名
        /// </summary>
     
        public string UserNmae { get; set; }

        /// <summary>
        /// 登录编号
        /// </summary>
      
        //[Unique]
        public string UserLoginCode { get; set; }
        /// <summary>
        /// 登录密码
        /// </summary>
      
        public string UserLoginPwd { get; set; }

        public virtual IList<RoleManagement> Role_Ids { get; set; }


    }
}
